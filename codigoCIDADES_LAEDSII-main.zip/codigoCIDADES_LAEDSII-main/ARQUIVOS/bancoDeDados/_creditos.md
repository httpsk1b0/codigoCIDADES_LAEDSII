http://www.consultaesic.cgu.gov.br/busca/dados/Lists/Pedido/Item/displayifs.aspx?List=0c839f31%2D47d7%2D4485%2Dab65%2Dab0cee9cf8fe&ID=1012693&Web=88cc5f44%2D8cfe%2D4964%2D8ff4%2D376b5ebb3bef

http://www.consultaesic.cgu.gov.br/busca/dados/Lists/Pedido/Attachments/1012693/RESPOSTA_PEDIDO_Coordenadas_Sedes_Municipios.zip